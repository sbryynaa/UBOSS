   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy; <?php echo date('Y');?> U-BOSS System 
                </div>

            </div>
        </div>
    </section>